<?php
define('HOST', 'localhost');
define('USER', 'root');
define('PASSWORD', 'root');
define('DATABASE', 'task4');
date_default_timezone_set('Europe/Belgrade');